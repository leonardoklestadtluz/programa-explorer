const buscarPessoas = () => axios.get("https://jsonplaceholder.typicode.com/users")

const mostrarPessoasNoConsole = pessoas => console.log(pessoas)

async function start() {
  try {
    const { data } = await buscarPessoas()

    if(data[0].email.includes("1") == false) {
      throw new Error("DEU RUIM")
    }

    mostrarPessoasNoConsole(data)
  } catch (err) {
    console.log("ERRO", err)
  } finally {
    console.log("FESTAAA")
  }
}

start()

















// .then(res => res.json())
// .then(data => {
//   pessoas = data
//   console.log(pessoas[0].name)
// })










 



/*

fetch("https://jsonplaceholder.typicode.com/users")
.then((res) => {
  res.json()
  .then((data) => {
    pessoas = data
    console.log(pessoas[4].name)
  })
})



setTimeout(() => {
  pessoas = ["jair","vini","marco"]
  console.log(pessoas[0])
}, 1000)
 
*/