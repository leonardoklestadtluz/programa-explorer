# Sícrono vs Assíncrono

## Síncrono

Executa uma tarefa de cada vez.

- linha a linha
- comando a comando
- instrução a instrução

JS é single thread non-blocking. Em outras palavras, Javascript é síncrono.

## Assíncrono

Quando uma instrução é muito demorada para ser executada, essa instrução é retirada da fila de execução adicionada em outro local. Quando terminada sua execução, ela retorna para fila de execução.