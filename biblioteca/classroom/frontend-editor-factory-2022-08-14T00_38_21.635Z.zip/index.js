/** CONCEITO DE FACTORY
 * É uma função que retorna um objeto.
 */

// OBJECT LITERAL
const pessoa1 = {
  nome: "Renan",
  idade: 15,
  maiorDeIdeade: false,
  dizerOla: function(){
    console.log("Olá")
  }
}
const pessoa2 = {
  nome: "Judite",
  idade: 17,
  maiorDeIdeade: false
}
const pessoa3 = {
  nome: "Astolfo",
  idade: 23,
  maiorDeIdeade: true
}
const pessoa4 = {
  nome: "Carolina",
  idade: 26,
  maiorDeIdeade: true
}


// Escalando aplicação sem o uso da Factory
const Mascara = {
  cpf(n) {},
  cnpj(n) {},
  cep(n) {},
  tel(n) {},
}

Mascara.cpf(12312312334)


// FACTORY

// Fábrica de pessoas
function criarPessoa(nome, idade) {
  return {
    nome,
    idade,
    maiorDeIdade: idade >= 18,
    dizerOla: function(){
      console.log("Olá")
    }
  }
}

criarPessoa("Judeu", 65)
criarPessoa("Maria", 90)
criarPessoa("Aristeu", 67)


// Fábrica de biscoitos
function formaDeBiscoitos(tipo) {
  return {
    tipo,
    quebrar: function() {
      return "quebrou"
    }
  }
}

const salgado = formaDeBiscoitos("salgado")
const doce = formaDeBiscoitos("doce")

console.log(doce.tipo)
console.log(salgado.tipo)
console.log(salgado.quebrar())
console.log(doce.quebrar())


// Fábrica de carros
const fabricaDeCarros = (marca, nome, motor) => {
  return {
    marca,
    nome,
    motor
  }
}

const mustang = fabricaDeCarros("Ford", "Mustang", 6.4)
const corvette = fabricaDeCarros("Chevrolet", "Corvette", 7.0)
const audiTT = fabricaDeCarros("Audi", "Audi TT", 5.2)

console.log(audiTT.motor)
console.log(corvette.motor)

// COSNTRUCTOR

// Construtor de motos
function Moto(marca, ano, modelo) {
  this.marca = marca
  this.ano = ano
  this.modelo = modelo

  this.sobre = function() {
    console.log(
      this.marca,
      this.ano
    )
  }
}

const honda = new Moto("Hornet", 2015)
const kawazaki = new Moto("Kawazaki Ninja", 2018)

honda.sobre()
kawazaki.sobre()