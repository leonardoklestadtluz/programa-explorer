# Flex

## Elementos com display Block
- posicionam elementos um abaixo do outro (vertical)

## Elementos com display inline
- posicionam elementos um ao lado do outro (horizontal)