# GRID

## Propriedades

- ALIGN
  - align-items -> 
  - align-content -> 
  - align-self -> 

- JUSTIFY
  - justify-items -> 
  - justify-content -> 
  - justify-self -> 