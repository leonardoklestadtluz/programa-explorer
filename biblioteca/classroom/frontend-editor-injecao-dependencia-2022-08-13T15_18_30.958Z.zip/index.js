const objeto1 = {
  say: function() {
    console.log('CONECTANDO NO BANCO 1')
  }
}

const objeto2 = {
  say: function() {
    console.log('CONECTANDO NO BANCO 2')
  }
}

/**
 * Função que depende de um objeto que tenha a
 * a função say() dentro dele
 */
function message(m) {
  m.say()
}

message(objeto1)