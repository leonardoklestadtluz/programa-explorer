// DOM
// Document Object Model

let play = document.querySelector('.play')
play.classList.add('hide')

document.querySelector('.pause')
.classList.remove('hide')