import { FavoritesView } from "./Favorites.js";

new FavoritesView("#app")